﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioButton : MonoBehaviour {
    public AudioClip[] Clips;

    protected AudioSource Source;

	// Use this for initialization
	void Start () {
        Source = GetComponent<AudioSource>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void OnPlay()
    {
        // detect if no clips are present
        if (Clips.Length == 0)
        {
            Debug.LogError("No clips setup");
            return;
        }

        // pick a random clip
        AudioClip selectedClip = Clips[Random.Range(0, Clips.Length)];

        // Randomise the pitch and play the sound
        Source.pitch = Random.Range(0.9f, 1.1f);
        Source.PlayOneShot(selectedClip);
    }
}
